<?php session_start();

require "../utility.php";

if (!isset($_SESSION["info"])) {
  header("Location: ../index.php");
  exit();
}


if ($_SESSION["info"]["position"] != "user") {
  header("Location: ../admin/product/welcome.php");
  exit();
}

$username = $_SESSION["info"]["username"];
$token = $_SESSION["info"]["token"];
$role = $_SESSION["info"]["position"] == "admin" ? "Administrator" : "user";
?>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0px;
}

.navbar {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000; /* Ensure it's above other content */
  background-color: #eb8431;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  margin:5px;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  background-color: inherit;
  font-family: inherit;
  margin-right: 70px;
}

  .dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1001; /* Set a higher value to ensure it's above other content */
  top: 50px; /* Adjust this value to customize vertical position */
  right: 20px; /* Position the dropdown content to the right */
}


.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: center;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.profile {
  padding: 20px;
  text-align: center;
}

.round-image {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  margin-bottom: 10px;
}

.profile h2 {
  font-size: 18px;
  margin-bottom: 5px;
}

.profile p {
  font-size: 16px;
  margin: 5px 0;
}
.image{
  width: 45px;
  height: 40px;
  border-radius: 50%;
  margin: 5px;
}


</style>
</head>
<body style="background-color:white;">

<div class="navbar">
  <a href="welcome.php">Home</a>
  <div class="dropdown" style="float: right">
    <button class="dropbtn"> 
      <img src="user.jpg" class="image">
    </button><br><br><br>
    <div class="dropdown-content">
    <div class="profile">
    <img src="./user.jpg" class="round-image">
    <h2>Profile</h2>
    <p>Name: <?php echo $username; ?> </p>
    <p>Role: <?php echo $role; ?></p>
  </div>
      <a class="link" href="../logout.php" style="color: #eb8431;" onclick="return confirmLogout()">Logout</a>
    </div>
  </div>
</div>

</body>
</html>
