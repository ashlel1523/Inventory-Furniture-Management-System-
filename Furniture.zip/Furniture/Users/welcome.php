
<?php include "nav.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="../style2.css">
</head>
<style>
    .modal {
      display: none; 
      position: fixed; 
      z-index: 1000; 
      padding-top: 20px; 
      left: 0;
      top: 0;
      width: 100%; 
      height: 100%; 
      overflow: auto; 
      background-color: rgb(0,0,0); 
      background-color: rgba(0,0,0,0.9); 
    }

    .modal-content {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
    }

    #img01 {
      width: 100%;
    }

    .close {
      position: absolute;
      top: 15px;
      right: 35px;
      color: #fff;
      font-size: 40px;
      font-weight: bold;
      transition: 0.3s;
    }

    .close:hover,
    .close:focus {
      color: #bbb;
      text-decoration: none;
      cursor: pointer;
    }

    .container {
  position: relative;
  padding: 
}

form {
  padding-top: 20px;
  position: absolute;
  width: 100%;
  top: 0;
}

.box-content{
  justify-content: center;
  margin: 30px;
}
.box-layout {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.box {
  width: calc(25% - 20px); 
  margin-bottom: 20px;
  background-color: #f9f9f9;
  border: 1px solid #ddd;
  display: flex;
  flex-direction: row;
  align-items: center;
}

.box-image {
  max-width: 100px;
  cursor: pointer;
  margin-right: auto; 
  margin-left: 90px
}

.box-content {
  display: flex;
  flex-direction: column;
}

.box-details {
  flex-grow: 1;
  padding: 20px;
}

.box-name {
  font-weight: bold;
  text-align: center;
}

.box-description {
  color: #666;
}

.box-quantity,
.box-price {
  margin-top: 10px;
}

  </style>
<body>

<div class="container">
  <h2>Furnitures </h2>
  <form action="" method="GET">
    <input type="text" name="search" id="searchInput" class="form-control" placeholder="Search...">
  </form>
  <?php
    $connection = dbconnect();

    $results_per_page = 8;
    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $results_per_page;

    if(isset($_GET['search'])) {
        $search_query = $_GET['search'];

        $sql = "SELECT * FROM product WHERE (pstatus != 'bin' AND pstatus != 'archived') AND (prod_name LIKE '%$search_query%' OR prod_desc LIKE '%$search_query%') LIMIT $offset, $results_per_page";
        $result = $connection->query($sql);
    } else {

        $sql = "SELECT * FROM product WHERE pstatus != 'bin' AND pstatus != 'archived' LIMIT $offset, $results_per_page";
        $result = $connection->query($sql);
    }
?>
  <div class="box-layout">
    <?php foreach ($result as $row) { ?>
      <div class="box">
        <div class="box-content">
          <img src="../uploads/<?php echo $row['photo']; ?>" alt="Product Image" class="box-image" onclick="openModal('<?php echo $row['photo']; ?>')">
          <div class="box-details">
            <div class="box-name"><?php echo $row["prod_name"]; ?></div>
            <div class="box-description"><?php echo "Description:<br>". $row["prod_desc"]; ?></div>
            <div class="box-price"><?php echo"Price: ". "₱" . number_format($row["price"], 2); ?></div>
          </div>
        </div>
      </div>
    <?php } ?>
  </div>
  <?php

    $count_query = "SELECT COUNT(*) AS total FROM product WHERE pstatus != 'bin' AND pstatus != 'archieved'";
    $count_result = $connection->query($count_query);
    $row_count = $count_result->fetch_assoc()['total'];
    $total_pages = ceil($row_count / $results_per_page);

    $prev_page = $current_page - 1;
    $next_page = $current_page + 1;
?>

<div class="pagination">
    <?php if ($current_page > 1): ?>
        <a href="?page=<?php echo $prev_page; ?>"><<</a>
    <?php endif; ?>
    
    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <?php if ($i == $current_page): ?>
            <a class="active" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php else: ?>
            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($current_page < $total_pages): ?>
        <a href="?page=<?php echo $next_page; ?>">>></i></a>
    <?php endif; ?>
</div>


</div>
</div>
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="img01">
  </div>
</body>


<script>
function openModal(imageSrc) {
      var modal = document.getElementById("myModal");
      var modalImg = document.getElementById("img01");
      modal.style.display = "block";
      modalImg.src = "../uploads/" + imageSrc;
    }

    function closeModal() {
      var modal = document.getElementById("myModal");
      modal.style.display = "none";
    }

  function confirmLogout() {
    return confirm("This will logging out you from this application.\n Do you still want to continue?");
  }


  function confirmDelete() {
    return confirm("This link will moved the selected data on the bin, after that you are still able to restore it.\n\n Do you still want to continue?");
  }


  function confirmArchieved() {
    return confirm("This link will archived the selected data, after that you are still able to restore it.\n\n Do you still want to continue?");
  }
</script>
</html>