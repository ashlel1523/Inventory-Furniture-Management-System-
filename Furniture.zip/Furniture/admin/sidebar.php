<?php
session_start();
if (!isset($_SESSION["info"])) {
  header("Location: ../../index.php");
    exit();
  }

  if ($_SESSION["info"]["position"] != "admin") {
    header("Location: ../../index.php");
    exit();
  }
  
$username = $_SESSION["info"]["username"];
$token = $_SESSION["info"]["token"];
$role = $_SESSION["info"]["position"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
  display: block;
  margin: 0px;
}

.navbar {
  overflow: hidden;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000; /* Ensure it's above other content */
  background-color: #eb8431;
}

.navbar a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

.navbar a.link {
  position: fixed;
  top: 3;
  right: 20px; /* Adjust as needed */
  color: white;
}

.span{
  display: block;
}

.sidebar {
  height: 100%;
  width: 230px; /* Initial width */
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #eb8431;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidebar.closed {
  width: 50px; /* Adjusted width when closed */
}

.sidebar a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  transition: 0.3s;
  display: block;
}

#side {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 23px;
  color: white;
  transition: 0.3s;
  display: block;
}

#icon {
  padding: 8px 8px 8px 20px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  transition: 0.3s;
  display: none;
}



.sidebar a:hover {
  color: #f1f1f1;
}

.sidebar .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

.profile {
  margin-left: auto;
  margin-right: auto;
  padding: 10px;
  transition: 0.5s;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.profile h2 {
  margin-top: 0;
  display: block;
  color:#f1f1f1;
}

.profile p {
  margin-top: 5px;
  font-size: 16px;
  display: block;
  color:#f1f1f1;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #f78e16;
  color: white;
  padding: 10px 15px;
  border: none;
}

.round-image {
  border-radius: 50%; /* This will make the image round */
  height: 150px; /* Initial height */
  transition: 0.5s; /* Add transition for smooth resizing */
}

.sidebar.closed .profile h2,
.sidebar.closed .profile p,
.sidebar.closed #side {
  display: none; /* Hide paragraphs and links when sidebar is closed */
}

.sidebar.closed #icon {
  display: block; /* Hide paragraphs and links when sidebar is closed */
}

#main {
  transition: margin-left .5s;
}

/* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
</style>
</head>
<body>
<div id="main"> 
<div class="navbar">
<a href="javascript:void(0)" class="openbtn" onclick="toggleNav()">☰</a>
  <a class="link" style="float: right; color: white;" href="../../logout.php" onclick="return confirmLogout()">Logout</a>
</div>

<div id="mySidebar" class="sidebar">
  <div class="profile">
    <img src="../admin.jpg" class="round-image">
    <h2>Profile</h2>
    <p>Name: <?php echo $username; ?> </p>
    <p>Role: <?php echo $role; ?></p>
  </div>
  <a id="side" href="../product/welcome.php">
  <img height="25px" src="../../icons/furniture.png" style="margin-right: 5px;">
  <span>Products</span></a>
  <a id="side" href="../archieve/info.php">
  <img height="25px" src="../../icons/arch.png" style="margin-right: 5px;">
  <span>View Archived</span></a>
  <a id="side" href="../bin/info.php">
  <img height="25px" src="../../icons/bin.png" style="margin-right: 5px;">
  <span>View Bin</span></a>

  <a id="icon" href="../product/welcome.php">
  <img height="35px" src="../../icons/furniture.png"></a>
  <a id="icon" href="../archieve/info.php">
  <img height="35px" src="../../icons/arch.png" style="margin-right: 5px;">
  </a>
  <a id="icon" href="../bin/info.php">
  <img height="35px" src="../../icons/bin.png" style="margin-right: 5px;"></a>
</div>


<script>
function toggleNav() {
  var sidebar = document.getElementById("mySidebar");
  if (sidebar.classList.contains("closed")) {
    // If sidebar is closed, open it
    sidebar.classList.remove("closed");
    sidebar.style.width = "230px";
    document.getElementById("main").style.marginLeft = "230px";
    document.querySelector(".round-image").style.height = "150px"; // Ensure image is at full size when sidebar opens
  } else {
    // If sidebar is open, close it
    sidebar.classList.add("closed");
    sidebar.style.width = "80px";
    document.getElementById("main").style.marginLeft = "80px";
    document.querySelector(".round-image").style.height = "50px";
  }
}

// Close the nav by default
toggleNav();
</script>

   
</body>
</html>
