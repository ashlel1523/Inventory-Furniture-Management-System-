<?php
  session_start();

  // check if the info session and the id parameter is defined 
  // if aren't, redirect to the login page
  if (!isset($_SESSION["info"]) || !isset($_GET["id"])) {
    header("Location: ../");
    exit();
  }

  require '../../utility.php';

  // connect to the database
  $connection = dbconnect();

  // Get the id parameter
  $id = $connection->real_escape_string(trim($_GET["id"]));

  $result = $connection->query("SELECT * FROM product WHERE ptoken = '$id'");

  if ($result->num_rows == 0) {
    echo "<script>alert('Person not found');</script>";
    echo "<script>window.location = '../product/welcome.php';</script>";
    exit();
  }

  $row = $result->fetch_all(MYSQLI_ASSOC);

  // update the PI_STATUS of the personal_info and set to active, so that it will be removed from the archieved
  $connection->query("UPDATE product SET pstatus = 'active' WHERE ptoken = '$id'");
  echo "<script>alert('Record of " . $row[0]["prod_name"] . " is successfully restored.');</script>";
  echo "<script>window.location = './info.php';</script>";
?>