<?php include "../sidebar.php"?>
<?php

if (!isset($_SESSION["info"])) {
  header("Location: ../../index.php");
    exit();
  }

  if ($_SESSION["info"]["position"] != "admin") {
    header("Location: ../../index.php");
    exit();
  }

require '../../utility.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Archived Data</title>
  <link rel="stylesheet" href="../../style2.css">
  <style>
    /* Style for the modal */
    .modal {
      display: none;
      position: fixed; 
      z-index: 1000; 
      padding-top: 20px; 
      left: 0;
      top: 0;
      width: 100%; 
      height: 100%; 
      overflow: auto; 
      background-color: rgb(0,0,0); 
      background-color: rgba(0,0,0,0.9); 
    }

    /* Style for the modal content */
    .modal-content {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
    }

    /* Style for the image inside the modal */
    #img01 {
      width: 100%;
    }

    .close {
      position: absolute;
      top: 15px;
      right: 35px;
      color: #fff;
      font-size: 40px;
      font-weight: bold;
      transition: 0.3s;
    }

    .close:hover,
    .close:focus {
      color: #bbb;
      text-decoration: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
< id="main">
<div class="container">
  <h2>Archived</h2>
  <form action="" method="GET">
    <input type="text" name="search" id="searchInput" class="form-control" placeholder="Search...">
  </form>
  <table>
  <thead>
      <th>Name</th>
      <th>Description</th>
      <th>Photo</th>
      <th>Quantity</th>
      <th>Price</th>
      <th>Action</th>

    </thead>
    <tbody>
      <?php
      $connection = dbconnect();
    
    $results_per_page = 5;
    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $results_per_page;


    // Check if a search query is submitted
    if(isset($_GET['search'])) {
        $search_query = $_GET['search'];
        // Modify the SQL query to include the search query with pagination
        $sql = "SELECT * FROM product WHERE (pstatus = 'archived') AND (prod_name LIKE '%$search_query%' OR prod_desc LIKE '%$search_query%')";
        $result = $connection->query($sql);
    } else {
        // If no search query is submitted, fetch all data with pagination
        $sql = "SELECT * FROM product WHERE pstatus = 'archived' LIMIT $offset, $results_per_page";
        $result = $connection->query($sql);
    }

      if ($result->num_rows > 0) {
        foreach ($result as $row) {
      ?>
      <tr>
        <td class="cell" ><?php echo $row["prod_name"]; ?></td>
        <td class="cell"><?php echo $row["prod_desc"]; ?></td>
        <td class="cell-image"><img src="../../uploads/<?php echo $row['photo']; ?>" alt="Product Image" style="max-width: 100px; cursor: pointer;" onclick="openModal('<?php echo $row['photo']; ?>')"></td>
        <td class="cell"><?php echo $row["prod_qty"]; ?></td>
        <td class="cell"><?php echo "₱" . number_format($row["price"], 2); ?></td>
        <td class="cell">
        <div class="button-container">
        <button class="button" onclick="window.location ='../edit/?id=<?php echo $row['ptoken']; ?>'">
        <img height="30px" src="../../icons/edit.png">
</button>
        <button class="button" onclick="if(confirm('Are you sure you want to delete?')){location.href='../bin/?id=<?php echo $row['ptoken']; ?>';}">
        <img height="30px" src="../../icons/delete.png">
      </button>
        <button class="button" onclick="if(confirm('Are you sure you want to restore?')){location.href='../archieve/restore.php?id=<?php echo $row['ptoken']; ?>';}">
        <img height="30px" src="../../icons/restore.png">
      </button>
        </div>
      </td>
      </tr>
      <?php
        }
      } else {
      ?>
      <tr>
        <td colspan=6 style="text-align: center;"><i>No Available data</i></td>
      </tr>
      <?php
      }
      ?>
    <tbody>
  </table>

  <?php
    // Count total number of rows
    $count_query = "SELECT COUNT(*) AS total FROM product WHERE pstatus = 'archived'";
    $count_result = $connection->query($count_query);
    $row_count = $count_result->fetch_assoc()['total'];
    $total_pages = ceil($row_count / $results_per_page);

    // Previous and next page logic
    $prev_page = $current_page - 1;
    $next_page = $current_page + 1;
?>

<div class="pagination">
    <?php if ($current_page > 1): ?>
        <a href="?page=<?php echo $prev_page; ?>"><<</a>
    <?php endif; ?>
    
    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <?php if ($i == $current_page): ?>
            <a class="active" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php else: ?>
            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($current_page < $total_pages): ?>
        <a href="?page=<?php echo $next_page; ?>">>></a>
    <?php endif; ?>
</div>
</div>
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="img01">
  </div>
</body>
<script>
function openModal(imageSrc) {
      var modal = document.getElementById("myModal");
      var modalImg = document.getElementById("img01");
      modal.style.display = "block";
      modalImg.src = "../../uploads/" + imageSrc;
    }

    function closeModal() {
      var modal = document.getElementById("myModal");
      modal.style.display = "none";
    }

  // function that will be called if logout link is clicked
  function confirmLogout() {
    return confirm("This will logging out you from this application.\nDo you still want to continue?");
  }

  // function that will be called if Delete link is clicked
  function confirmDelete() {
    return confirm("This link will moved the selected data on the bin, after that you are still able to restore it.\n\n Do you still want to continue?");
  }

  // function that will be called if Archieved link is clicked
  function confirmRestore() {
    return confirm("This link will restore the selected data and will be removed from the archived.\n\n Do you still want to continue?");
  }
</script>
</html>