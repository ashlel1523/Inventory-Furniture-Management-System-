<?php
  if (!isset($_POST["prod_name"]) || !isset($_POST["prod_desc"]) || !isset($_POST["prod_qty"]) || !isset($_POST["price"]) || !isset($_POST["mode"])) {
    header("Location: ../product/add.php");
    exit();
  }

  require '../../utility.php';

  $name = trim($_POST["prod_name"]);
  $desc = trim($_POST["prod_desc"]);
  $qty = trim($_POST["prod_qty"]);
  $price = trim($_POST["price"]);
  $mode = trim($_POST["mode"]);
  $id = "";

  if (isset($_POST["id"]))
    $id = $_POST["id"];

  // connect to the database
  $connection = dbconnect();

  // sanitize all user input
  $name = input($name, $connection);
  $desc = input($desc, $connection);
  $qty = input($qty, $connection);
  $price = input($price, $connection);
  $mode = input($mode, $connection);
  
  $photo = "";
  if(isset($_FILES['photo']['name']) && !empty($_FILES['photo']['name'])) {
    $photo = basename($_FILES['photo']['name']);
    $target_dir = "../../uploads/"; // Specify the correct path to the directory where you want to store uploaded files
    $target_file = $target_dir . $photo;
    // Move the uploaded file to the uploads directory
    if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
      echo "Error uploading file.";
      exit(); // Exit script if upload fails
    }
  }


  if ($mode == "register") {
    // Generate random token for the new student
    $token = generate_token();
    $connection->query("insert into product VALUES(NULL, '$name', '$desc', '$qty','$photo', '$price' ,'$token' , 'active')");
    $id = $connection->insert_id;

    echo "<script>";
    echo "alert('Record was successfully saved.');";
    echo "window.location = '../product/welcome.php';";
    echo "</script>";
  } else {
    $info = $connection->query("SELECT * FROM product WHERE ptoken = '$id'");

    if ($info->num_rows == 0) {
      echo "<script>";
      echo "alert('Person not found');";
      echo "window.location = '../product/welcome.php';";
      echo "</script>";
      exit();
    }

    if (!empty($photo)) {
      $connection->query("UPDATE product SET prod_name = '$name', prod_desc = '$desc', photo = '$photo', prod_qty = '$qty',  price = '$price' WHERE ptoken = '$id'");
    } else {
      $connection->query("UPDATE product SET prod_name = '$name', prod_desc = '$desc', prod_qty = '$qty',  price = '$price' WHERE ptoken = '$id'");
    }
    
    echo "<script>";
    echo "alert('Changes in record was successfully saved.');";
    echo "window.location = '../product/welcome.php?id=$id';";
    echo "</script>";
  }
?>