<?php include "../sidebar.php";?>
<?php
  if (!isset($_SESSION["info"])) {
    header("Location: ../../");
    exit();
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<style>
    .container{
        padding-top: 100px;
    }
    .form-container {
        max-width: 400px;
        margin: 0 auto;
        background-color: #f2f2f2;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form-container h3 {
        text-align: center;
        margin-bottom: 20px;
    }

    .form-container label {
        display: block;
        margin-bottom: 5px;
    }

    .form-container input[type="text"],
    .form-container textarea,
    .form-container input[type="number"],
    .form-container input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .form-container .buttons {
        text-align: center;
    }

    .form-container input[type="submit"] {
        padding: 10px 20px;
        background-color: blue;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .form-container input[type="submit"]:hover {
        background-color: blue;
    }
</style>
<div class="container">
<div class="form-container">
    <form action="../save/" method="POST" enctype="multipart/form-data" >
        <h3>Add Product</h3>
        <input type="hidden" name="mode" value="register">
        <input type="hidden" name="id">

        <label for="prod_name">Name:</label>
        <input type="text" id="prod_name" name="prod_name" required>

        <label for="prod_desc">Description:</label>
        <textarea id="prod_desc" name="prod_desc" required></textarea>

        <label for="photo">Photo:</label>
        <input type="file" id="photo" name="photo" required>

        <label for="prod_qty">Quantity:</label>
        <input type="number" id="prod_qty" name="prod_qty" required>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" required>

        <div class="buttons">
            <input type="submit" value="Add">
        </div>
    </form>
</div>
</div>
</html>