<?php
session_start();

// check if session info is already defined
// if it is defined redirect to welcome.php
if (isset($_SESSION["info"])) {
  header("index.php");
  exit();
}

$username = "";

if (isset($_GET["username"]))
  $username = $_GET["username"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="background-container">
    <div class="background-overlay">
        <div id="login_form" style=" width: 300px">
            <div class="form">
                <form action="reg.php" method="POST">
                    <h3>Signup</h3>
                    <input type="text" name="user_name" placeholder="Username" value="<?php echo htmlentities($username); ?>">
                    <input type="password" name="password" placeholder="Password" <?php if (!empty($username)) echo "autofocus"; ?>>
                    <button type="submit" value="Signup">submit</button>
                </form><br>
                <a href="index.php">Login</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>