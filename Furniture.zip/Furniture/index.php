<?php
session_start();

if (isset($_SESSION["info"])) {
    header("Location: ./Users/welcome.php");
    exit();
  }
  
  $username = isset($_GET["username"]) ;
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="background-container">
    <div class="background-overlay">
        <div id="login_form" style=" width: 300px">
            <div class="form">
                <form action="login.php" method="POST">
                    <h2><img class="sm" style= "width:100px; height:80px; margin-left: 100px" src="logo.jpg"></h2>
                    <h3>Login</h3>
                    <input type="text" name="username" placeholder="Username" value="<?php echo htmlentities($username); ?>">
                    <input type="password" name="password" placeholder="Password" <?php if (!empty($username)) echo "autofocus"; ?>>
                    <button type="submit" value="Log In">Login</button><br>
                </form><br>
                <a href="regform.php">Create an Account</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
