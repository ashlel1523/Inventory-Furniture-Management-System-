<?php
if (!isset($_POST["user_name"]) || !isset($_POST["password"])) {
  header("Location: regform.php");
  exit();
}

require "./utility.php";

$user_name = trim($_POST["user_name"]);
$userpass = trim($_POST["password"]);

$con = dbconnect();

$username = input($user_name, $con);
$password = input($userpass, $con);

$token = generate_token(); 

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $con->prepare("INSERT INTO users (user_name, userpass, token, userpos) VALUES (?, ?, ?, 'user')");
$stmt->bind_param("sss", $username, $password_hash, $token);

$stmt->execute();

$id = $stmt->insert_id;

$stmt->close();

echo "<script>";
echo "alert('Record was successfully saved.');";
echo "window.location = 'index.php';";
echo "</script>";
?>
