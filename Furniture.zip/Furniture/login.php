<?php
if (!isset($_POST["username"]) || !isset($_POST["password"])) {
  header("Location: index.php");
  exit();
}

require "./utility.php";

$username = trim($_POST["username"]);
$password = trim($_POST["password"]);

$con = dbconnect();

$username = input($username, $con);
$password = input($password, $con);

$result = $con->query("SELECT user_name, userpass, token, userpos FROM users WHERE user_name = '$username'");

if ($result->num_rows == 0) {
  user_not_found($username);
} else {
  $row = $result->fetch_all(MYSQLI_ASSOC);
  $password_hash = $row[0]["userpass"];

  if (password_verify($password, $password_hash)) {
    session_start();

    $_SESSION["info"] = [
      "username" => $row[0]["user_name"],
      "token" => $row[0]["token"],
      "position" => $row[0]["userpos"]
    ];

    if ($row[0]["userpos"] === "admin") {
      header("Location: ./admin/product/welcome.php");
    } else {
      header("Location: ./Users/welcome.php");
    }
    exit();

  } else {
    header("Location: ./index.php");
    user_not_found($username);
  }
}
?>
