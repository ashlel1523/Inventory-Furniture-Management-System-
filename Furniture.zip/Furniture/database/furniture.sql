-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2024 at 11:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furniture`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_desc` text NOT NULL,
  `prod_qty` double NOT NULL,
  `photo` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `ptoken` varchar(80) NOT NULL,
  `pstatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `prod_name`, `prod_desc`, `prod_qty`, `photo`, `price`, `ptoken`, `pstatus`) VALUES
(31, 'Bed', 'A sturdy bed frame with soft, profile edges and high legs. A classic shape that will last for many years. Also, there are spacious storage boxes under the bed where you can store bedding or clothes.', 42, 'Sabrina-.jpg', 100000, 'eUtxj1cncwn23w611CCi', 'active'),
(34, 'Chair', 'Door Wooden Wardrobe Cabinet Storage Multi Purpose Functional simple assembly organizer for clothes cabinet clothes organizer cabinet clothes organizer wooden', 31, 'NEW_Boucle_Occasional_Chair_Lores_01__72226.jpg', 10000, 's2ZHbLxKEQgrAxxKFF31', 'active'),
(49, 'Sofa', 'With its soft shapes, modern expressions and durable light cover, this sofa is a perfect combination of function and comfort. Also available with a chaise for those who like to stretch out.', 80, 'sofa.jpg', 13000, 'CXZsDCQHodh9N8teNmYz', 'active'),
(53, 'Armchair', 'POÄNG armchair has stylish curved lines in bentwood, providing nice support for the neck and comfy resilience. The footstool is the perfect companion and nice to rest your feet on. Want to try them too?', 20, 'armchair.jpg', 15000, 'X8fgoLX2VAvv3JSppHgS', 'active'),
(54, 'Coffee Table', 'JAKOBSFORS is a sleek and airy coffee table with a natural wood look. The modern design with a simple and honest expression suits many interior styles – and you can therefore enjoy it for many years.', 30, 'coffeetable.avif', 7000, 'qPyalIC4MltxY1GtaDMh', 'active'),
(55, 'Dining Table and Chairs', 'A simple and sturdy set that’s perfect for your breakfast nook or smaller dining area. The solid pine holds up well over time and will endure all the family meals and activities around the table.', 90, 'dining table.avif', 17000, '6dEbuerUYHlqif1lveYw', 'active'),
(56, 'Wardrobe', 'Now you don’t have to choose between hanging or folding your clothes. In the compact VILHATTEN wardrobe, there is room for both. It also takes up little floor space – perfect in both a hallway and bedroom.', 80, 'wardrobe.avif', 6000, '7SmGrHWftQwz5HyzXNi2', 'active'),
(58, 'Drawer', 'A simple, functional chest of drawers that goes with any decor, in a bedroom or wherever you place it. There’s room for both your favorite clothes and extra bedding. Psst! Remember to anchor it to a wall.', 90, 'Drawer.avif', 5000, 'duNodV5LXfNqwGfZQoru', 'active'),
(59, 'Nightstand', 'This simple black nightstand is a little gem to have at home. Place it next to your bed or sofa, use it in small spaces or easily move it around for a more flexible home!', 40, 'TVstand.avif', 11000, '39N9G6pkdsnQiz43gHE8', 'active'),
(60, 'Bookshelf', 'Shelving unit or room divider – the KALLAX series adapts to taste, space, needs and budget. Smooth surfaces and rounded corners give a feel of quality and you can personalize the shelving unit with inserts and boxes.', 40, 'bookshelf.avif', 10000, '6vGer5JHntg7k3mCUXFO', 'active'),
(62, 'Desk', 'Limited space doesn’t mean you have to say no to studying or working from home. This desk takes up little floor space yet still has a drawer unit where you can store papers and other important items.', 90, 'desk.avif', 7000, 'VbCwIOFiXlJxuB0mRJJH', 'active'),
(63, 'Office Chair', 'This ergonomic office chair keeps you comfy and focused with features like a manually adjustable tilt tension, and head-/armrests to help relax the muscles in your neck and back. 10 year guarantee.', 100, 'office chair.avif', 8900, 'bIGYlekYxpO5Y1vhX6Ty', 'active'),
(65, 'Ottoman', 'This soft and beautiful pouffe can be used as an ottoman or extra seat. It is available in three sizes with knitted covers in different colors and patterns – perfect on their own or together!', 60, 'ottoman.jpg', 1999, 'PmQrYyPveTwqzMLzF9lB', 'active'),
(67, 'Sideboard', 'An airy yet stable sideboard with a rustic look that works just as well in the living room as in the dining area. The metal adds an industrial feel and the solid wood makes every piece of furniture unique.', 30, 'sideboard.avif', 6000, 'eW8eByP1MhoAxC9ZO2Vj', 'active'),
(71, 'TV stand', 'This LACK TV-bench is easy to match with other furniture. Thanks to the unique construction, it’s easy to assemble, lift and place - and we can keep the prices down, so your spirits go up.', 90, 'TVstand.avif', 3400, '18ipv2LuKRUa4dLKoNn9', 'active'),
(73, 'Bathroom Vanity', 'A simple, crafted look with Scandinavian appeal combined with modern function like smooth-running drawers and a water-saving faucet. The white finish is easy to coordinate with other furnishings.', 30, 'Bathroom Vanity.avif', 28000, '9J9OFZU4v1vkwSkGcaAV', 'active'),
(77, 'Rocking Chair', 'The layer-glued bent wood frame gives the armchair a comfortable resilience, making it perfect to relax in.', 80, 'rockingchair.avif', 10999, 'ZnyX0S4ZLq3fsM4ucVB5', 'active'),
(78, 'Sleeper Sofa', 'Soft shapes and big, comfy cushions will make you long for BÅRSLÖV sofa-bed. Here you can hang out, sit or sleep – and make use of the practical storage. Easy-care fabrics keep the sofa in good condition!', 40, 'sleeper sofa.avif', 39000, 'IvBteGwKFvmHeeZM6es7', 'active'),
(83, 'Cabinet Bed', 'With this daybed you quickly and easily create space for overnight guests. Just pull out the bed base and you get a double bed in no time.', 400, 'cabinet sofa.avif', 300000, '8cwfbRVRdVkeUSbvJvXd', 'active'),
(84, 'Cabinet wall', 'METOD kitchen system gives you endless possibilities to design your dream kitchen. Paired with NICKEBO fronts in matt black, you get a stylish and modern look that is easy to personalize.', 460, 'cabinet wall.avif', 10000, 'owbOhBDisLUopjHu9D0x', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `userpass` varchar(80) NOT NULL,
  `userpos` varchar(30) NOT NULL,
  `token` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `user_name`, `userpass`, `userpos`, `token`) VALUES
(1, 'admin', '$2a$04$n6XgFqsyqnHfiDdDw43IOuGdjRARVOcskQie9jv/hWDlGjA7wZXzS', 'admin', 'gI2O9v6qjeA9ej56GdsU'),
(9, 'user1', '$2y$10$i0USikA5lC.YpzCLaUjhv.JPPQbiILrWYaAz6Auvtt9kJddyuNOZO', 'user', 'FnxPNvG87LE1ogWp8NNL'),
(19, 'user', '$2y$10$OaNMCBjAVEs6J111PKBH8.Q6rCz4LYHzOKvX1Nbyt0dPs.MAC.XtW', 'user', 'PXcbEULbrrvHmClbXU4Q');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
