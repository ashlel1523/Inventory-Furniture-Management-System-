<?php
session_start();

if (isset($_SESSION["info"])) {
    if ($_SESSION["info"]["position"] === "admin") {
        header("Location: ./admin/product/welcome.php");
    } else {
        header("Location: ./Users/welcome.php");
    }
    exit();
}

  $username = "";
  
  if (isset($_GET["username"]))
    $username = $_GET["username"];
  ?>
